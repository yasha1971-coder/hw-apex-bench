LIBS = -lz -lm -lpthread
HTS_LIBS = -lz -lm -lpthread
NONCONFIGURE_OBJS =
